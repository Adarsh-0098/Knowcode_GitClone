import React from 'react'
import './bodydiy.css'
import Diyvideo from './diyvideo/diyvideo'
import Windowdiy from './windowdiy/windowdiy'
 
const Bodydiy = () => {
  return (
    <div className="maincontent11">
      <Diyvideo/>
    </div>
  )
}

export default Bodydiy